#introducimos la longitud del lado del traingulo
var_lado=int(input("introduce la longitud de un lado de un triangulo equilatero:"))
var_potencia=var_lado**2
var_area=0.43*var_potencia
print("el area del traingulo es:", var_area)
