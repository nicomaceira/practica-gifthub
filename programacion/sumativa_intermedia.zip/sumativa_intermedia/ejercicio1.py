#introducimos los dos numeros con los qu haremos la operacion
var1=float(input("introduce el primer numero:"))
var2=float(input("introduce el segundo numero:"))
#realizamos la suma
var_total=var1+var2
#mostramos el resultado por pantalla
print("el resultado de sumar", var1, "y", var2,"es:", var_total)
