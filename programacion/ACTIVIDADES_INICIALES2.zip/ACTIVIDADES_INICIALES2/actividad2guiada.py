print("comanda")
print("1.Hamburguesa")
print("2.Pizza")
print("3.Lentejas")
print("4.Bocadillo de jamon")
comanda=int(input("introduce el numero de tu pedido:"))
if comanda==1:
    print("tu pedido es una hamburguesa")
elif comanda==2:
    print("tu pedido es una pizza")
elif comanda==3:
    print("tu pedido son unas lentejas")
elif comanda==4:
    print("tu pedido es un bocadillo de jamon")
else:
    print("error de comanda")