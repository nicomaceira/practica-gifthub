#Programa que introduzca por teclado tres tipos de variables y se muestren por pantalla en el siguiente orden: número entero, texto y número decimal.
var1=input("introduce un numero entero:")
var2=input("introduce una frase:")
var3=input("introduce un numero decimal:")
print(var1)
print(var2)
print(var3)