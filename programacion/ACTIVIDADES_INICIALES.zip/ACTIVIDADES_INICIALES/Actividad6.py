
#A partir del programa 5. Haz que se muestre por pantalla también la frase en el orden inverso en que se han introducido las palabras.
var1=input("introduce una frase:")
var2=input ("introduce otra frase:")
var3=input("introduce otra frase:")
var4=input("introduce otra frase:")
var5=input("introduce, por ultima vez, una frase:")
print((var1),(var2),(var3),(var4),(var5))
print(var5,var4,var3,var2,var1)