# programa que pida los segundos y muestre por pantalla y en la misma frase los minutos y las horas
var1=int(input("introduce un numero:" ))
var2=int(input("introduce un numero:" ))
minvar1=var1/60
horvar1=minvar1/60
minvar2=var2/60
horvar2=minvar2/60
print("el numero de minutos del primer numero es:", minvar1, "y en horas es:", horvar1)
print("el numero de minutos del segundo numero es:", minvar2, "y en horas es:", horvar2)
