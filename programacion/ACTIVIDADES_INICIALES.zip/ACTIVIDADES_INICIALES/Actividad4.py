# A partir del código anterior, realiza una versión para números con decimales
var1= float(input("introduce un numero decimal:"))
var2= float(input("introduce otro numero decimal:"))
resultado=var1+var2
print("el resultado es:",resultado)