#programa que pida un número de horas y muestre por pantalla los minutos y segundos
var1=int(input("introduce un numero:" ))
var2=int(input("introduce un numero:" ))
minvar1=var1*60
segvar1=minvar1*60
minvar2=var2*60
segvar2=minvar2*60
print("el numero de minutos del primer numero es:", minvar1, "y en segundos es:", segvar1)
print("el numero de minutos del segundo numero es:", minvar2, "y en segundos es:", segvar2)
