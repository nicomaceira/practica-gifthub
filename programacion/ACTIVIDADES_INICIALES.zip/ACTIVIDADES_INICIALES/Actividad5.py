# Programa que pida cinco palabras y muestre una frase con las cinco. Modifica el código para que entre palabra y palabra haya una coma
var1=input("introduce una frase:")
var2=input ("introduce otra frase:")
var3=input("introduce otra frase:")
var4=input("introduce otra frase:")
var5=input("introduce, por ultima vez, una frase:")
print((var1),(var2),(var3),(var4),(var5))
frase=var1,var2,var3,var4,var5
print(frase)