# programa que calcule dos operandos con los 7 operadores vistos en clase. ¿Cómo puedes forzar que el resultado de la división tenga 2 decimales?
var1=float(input("introduce un numero:" ))
var2=float(input("introduce un numero:" ))
total=var1+var2
print("la suma de operador1 y operador2 es:", total)
total2=var1-var2
print("la resta de opetador1 y operador 2 es:",total2)
total3=var1*var2
print("la multiplicacion es:", total3)
total4=var1/var2
print("la division es:",round(var1/var2, 2))
total5=var1**var2
print("el exponente de operador1 y operador2 es:", total5)
total6=var1//var2
print("la division enera entre operador1 y operador2 es:", total6)